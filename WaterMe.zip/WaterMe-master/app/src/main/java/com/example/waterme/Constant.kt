package com.example.waterme

const val NODE_PLANTS= "plants"